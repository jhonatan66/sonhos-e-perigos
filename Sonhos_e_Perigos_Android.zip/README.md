# Sonhos & Perigos — Android

Este é o projeto Android nativo do protótipo.
A história roda dentro de um WebView usando `android_asset`, então as cenas não dependem do Chrome nem de `content://`.

Recursos:
- cenas e imagens incluídas no app;
- diálogos e escolhas;
- romance leve;
- efeitos sonoros;
- salvamento local;
- múltiplos caminhos/final do capítulo.

Para gerar o APK é necessário abrir este projeto em um ambiente Android com SDK/Gradle, como Android Studio ou uma IDE Android compatível.
